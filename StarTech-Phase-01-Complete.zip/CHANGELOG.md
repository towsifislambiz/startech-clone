# CHANGELOG - StarTech Clone

## [Phase 1: Project Stabilization] - 2026-08-01

### Added
- **Redux Toolkit Integration**: Installed `@reduxjs/toolkit` and `react-redux`. Added centralized store (`src/redux/store.js`) and slices: `cartSlice.js`, `authSlice.js`, `themeSlice.js`.
- **Global Error Handling**: Added `ErrorBoundary` component (`src/components/common/ErrorBoundary.jsx`).
- **Global Loading System**: Added `FullPageLoader`, `Spinner`, `CardSkeleton`, and `ButtonLoader` components in `src/components/common/`.
- **Reusable Product Components**: Extracted memoized `ProductCard` (`src/components/common/ProductCard.jsx`) and `Breadcrumbs` (`src/components/common/Breadcrumbs.jsx`).
- **Service Abstractions**: Created `api.js` with Axios interceptors, `productService.js`, and `authService.js`.
- **Custom Hooks**: Created `useDebounce`, `useLocalStorage`, `useScrollTop`, `useDocumentTitle`, and `usePagination` in `src/hooks/`.
- **Utility Modules**: Added `src/utils/formatters.js` and `src/utils/helpers.js`.
- **Centralized Constants**: Added `src/constants/index.js` for app-wide categories, brands, price ranges, and services.
- **Path Aliasing**: Configured `jsconfig.json` for `@/*` path mapping.

### Refactored & Improved
- **App.jsx**: Implemented Route Code Splitting with `React.lazy` & `Suspense`. Added `ErrorBoundary` and `ScrollToTop`.
- **Header.jsx**: Replaced inline nav arrays with `NAV_CATEGORIES` constant and enhanced accessibility (`aria-label`, `type="button"`).
- **Home.jsx**: Refactored product grid to use memoized `ProductCard` and centralized constants.
- **Category.jsx**: Standardized filter logic, memoized product list, and integrated `Breadcrumbs` and `ProductCard`.
- **Product.jsx**: Refactored price formatting, breadcrumbs, and gallery thumb interactions.
- **Cart.jsx & Checkout.jsx**: Replaced raw string formatting with `formatPrice` helper.
- **PCBuilder.jsx**: Enhanced accessibility and replaced manual currency formatting with `formatPrice`.
- **AuthContext.jsx**: Removed raw `console.error` statement and integrated with `authService`.

### Performance & Security
- Code-split routes reduce initial JS bundle load size.
- Lazy-loaded product image rendering (`loading="lazy"`).
- Component memoization on `ProductCard` to eliminate unnecessary parent re-renders.
- Graceful error boundary protection prevents white screen of death.
