import { createSlice } from '@reduxjs/toolkit';

const loadUserFromStorage = () => {
  try {
    const saved = localStorage.getItem('startech-user');
    return saved ? JSON.parse(saved) : null;
  } catch (err) {
    return null;
  }
};

const initialState = {
  user: loadUserFromStorage(),
  token: localStorage.getItem('startech-token') || null,
  loading: false,
  error: null,
};

export const authSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    setAuthSuccess: (state, action) => {
      const { user, token } = action.payload;
      state.user = user;
      state.token = token;
      state.loading = false;
      state.error = null;
      localStorage.setItem('startech-token', token);
      localStorage.setItem('startech-user', JSON.stringify(user));
    },
    logout: (state) => {
      state.user = null;
      state.token = null;
      state.loading = false;
      state.error = null;
      localStorage.removeItem('startech-token');
      localStorage.removeItem('startech-user');
    },
    setAuthLoading: (state, action) => {
      state.loading = action.payload;
    },
    setAuthError: (state, action) => {
      state.error = action.payload;
      state.loading = false;
    },
  },
});

export const { setAuthSuccess, logout, setAuthLoading, setAuthError } = authSlice.actions;

export const selectAuthUser = (state) => state.auth.user;
export const selectIsAuthenticated = (state) => !!state.auth.user && !!state.auth.token;

export default authSlice.reducer;
