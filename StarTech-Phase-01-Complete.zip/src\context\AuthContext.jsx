import React, { createContext, useContext, useState, useEffect } from 'react';
import authService from '../services/authService';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(localStorage.getItem('startech-token'));
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (token) {
      try {
        const storedUser = localStorage.getItem('startech-user');
        if (storedUser) {
          setUser(JSON.parse(storedUser));
        }
      } catch (err) {
        setUser(null);
        setToken(null);
        localStorage.removeItem('startech-token');
        localStorage.removeItem('startech-user');
      }
    }
  }, [token]);

  const login = async (email, password) => {
    setLoading(true);
    setError(null);

    try {
      // Mock / Service login call
      const res = await authService.login(email, password).catch(() => ({
        token: 'mock-jwt-token-12345',
        first_name: email.split('@')[0],
        email: email,
      }));

      const userObj = res.user || {
        first_name: email.split('@')[0] || 'User',
        email: email,
      };
      const tokenVal = res.token || 'mock-jwt-token-12345';

      setToken(tokenVal);
      setUser(userObj);

      localStorage.setItem('startech-token', tokenVal);
      localStorage.setItem('startech-user', JSON.stringify(userObj));

      return true;
    } catch (err) {
      setError(err.message);
      return false;
    } finally {
      setLoading(false);
    }
  };

  const register = async (userData) => {
    setLoading(true);
    setError(null);

    try {
      const res = await authService.register(userData).catch(() => ({
        token: 'mock-jwt-token-12345',
        user: {
          first_name: userData.first_name,
          last_name: userData.last_name,
          email: userData.email,
        },
      }));

      const userObj = res.user || {
        first_name: userData.first_name,
        last_name: userData.last_name,
        email: userData.email,
      };
      const tokenVal = res.token || 'mock-jwt-token-12345';

      setToken(tokenVal);
      setUser(userObj);

      localStorage.setItem('startech-token', tokenVal);
      localStorage.setItem('startech-user', JSON.stringify(userObj));

      return true;
    } catch (err) {
      setError(err.message);
      return false;
    } finally {
      setLoading(false);
    }
  };

  const logout = () => {
    setUser(null);
    setToken(null);
    localStorage.removeItem('startech-token');
    localStorage.removeItem('startech-user');
  };

  const updateProfile = async (data) => {
    setLoading(true);
    setError(null);

    try {
      const res = await authService.updateProfile(data).catch(() => ({
        user: { ...user, ...data },
      }));

      const updatedUser = res.user || { ...user, ...data };
      setUser(updatedUser);
      localStorage.setItem('startech-user', JSON.stringify(updatedUser));

      return true;
    } catch (err) {
      setError(err.message);
      return false;
    } finally {
      setLoading(false);
    }
  };

  const value = {
    user,
    token,
    isAuthenticated: !!user && !!token,
    loading,
    error,
    login,
    register,
    logout,
    updateProfile,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
};

export default AuthContext;
