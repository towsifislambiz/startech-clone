import React, { createContext, useContext, useState, useEffect } from 'react';
import { onAuthStateChanged } from 'firebase/auth';
import { useDispatch } from 'react-redux';
import { auth } from '../firebaseConfig';
import authService from '../services/authService';
import { saveUserProfileToFirestore } from '../services/firebaseAuthService';
import { setAuthUser, logoutUser, setAuthLoading } from '../redux/slices/authSlice';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [currentUser, setCurrentUser] = useState(null);
  const [userProfile, setUserProfile] = useState(() => {
    try {
      const saved = localStorage.getItem('startech-user');
      return saved ? JSON.parse(saved) : null;
    } catch (e) {
      return null;
    }
  });
  const [loading, setLoading] = useState(true);
  const dispatch = useDispatch();

  // Listen to Firebase Auth state change across page refreshes
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      setCurrentUser(firebaseUser);

      if (firebaseUser) {
        // Fetch or create Firestore user profile
        const profile = await saveUserProfileToFirestore(firebaseUser).catch(() => null);
        const mergedUser = {
          uid: firebaseUser.uid,
          email: firebaseUser.email,
          displayName: firebaseUser.displayName || profile?.displayName || '',
          firstName: profile?.firstName || (firebaseUser.displayName ? firebaseUser.displayName.split(' ')[0] : 'User'),
          lastName: profile?.lastName || '',
          photoURL: firebaseUser.photoURL || '',
          emailVerified: firebaseUser.emailVerified,
          role: profile?.role || 'user',
        };

        setUserProfile(mergedUser);
        localStorage.setItem('startech-user', JSON.stringify(mergedUser));
        dispatch(setAuthUser({ user: mergedUser, token: await firebaseUser.getIdToken().catch(() => null) }));
      } else {
        setUserProfile(null);
        localStorage.removeItem('startech-user');
        localStorage.removeItem('startech-token');
        dispatch(logoutUser());
      }

      setLoading(false);
      dispatch(setAuthLoading(false));
    });

    return () => unsubscribe();
  }, [dispatch]);

  // Signup
  const signup = async (email, password, name) => {
    setLoading(true);
    try {
      const result = await authService.signup(email, password, name);
      return result;
    } finally {
      setLoading(false);
    }
  };

  // Login
  const login = async (email, password, rememberMe = true) => {
    setLoading(true);
    try {
      const result = await authService.login(email, password, rememberMe);
      return result;
    } finally {
      setLoading(false);
    }
  };

  // Google Login
  const googleLogin = async () => {
    setLoading(true);
    try {
      const result = await authService.googleLogin();
      return result;
    } finally {
      setLoading(false);
    }
  };

  // GitHub Login
  const githubLogin = async () => {
    setLoading(true);
    try {
      const result = await authService.githubLogin();
      return result;
    } finally {
      setLoading(false);
    }
  };

  // Logout
  const logout = async () => {
    setLoading(true);
    try {
      await authService.logout();
      setUserProfile(null);
      setCurrentUser(null);
    } finally {
      setLoading(false);
    }
  };

  // Forgot Password
  const forgotPassword = async (email) => {
    setLoading(true);
    try {
      const result = await authService.forgotPassword(email);
      return result;
    } finally {
      setLoading(false);
    }
  };

  // Update Profile
  const updateProfile = async (profileData) => {
    setLoading(true);
    try {
      if (currentUser) {
        const result = await authService.updateProfile(currentUser, profileData);
        return result;
      }
      throw new Error('No user signed in');
    } finally {
      setLoading(false);
    }
  };

  // Send Email Verification
  const sendVerification = async () => {
    if (currentUser) {
      return await authService.sendEmailVerification(currentUser);
    }
    throw new Error('No user signed in');
  };

  const value = {
    currentUser,
    user: userProfile,
    isAuthenticated: !!userProfile,
    loading,
    signup,
    login,
    googleLogin,
    githubLogin,
    logout,
    forgotPassword,
    updateProfile,
    sendEmailVerification: sendVerification,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
};

export default AuthContext;
