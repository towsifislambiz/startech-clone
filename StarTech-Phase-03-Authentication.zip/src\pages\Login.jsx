import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { FcGoogle } from 'react-icons/fc';
import { FiGithub } from 'react-icons/fi';
import { useAuth } from '../context/AuthContext';
import { useNotification } from '../context/NotificationContext';
import ButtonLoader from '../components/Common/ButtonLoader';
import Input from '../components/Common/Input';
import { useDocumentTitle } from '../hooks/useDocumentTitle';

const Login = () => {
  const navigate = useNavigate();
  const { login, googleLogin, githubLogin } = useAuth();
  const { success: showSuccess, error: showError } = useNotification();
  useDocumentTitle('Login');

  const [formData, setFormData] = useState({ email: '', password: '', rememberMe: true });
  const [loading, setLoading] = useState(false);
  const [socialLoading, setSocialLoading] = useState(null); // 'google' | 'github' | null

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.email || !formData.password) {
      showError('Please enter both email and password');
      return;
    }

    setLoading(true);
    try {
      await login(formData.email, formData.password, formData.rememberMe);
      showSuccess('Logged in successfully!');
      navigate('/dashboard');
    } catch (err) {
      showError(err.message || 'Login failed. Please check your credentials.');
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    setSocialLoading('google');
    try {
      await googleLogin();
      showSuccess('Signed in with Google!');
      navigate('/dashboard');
    } catch (err) {
      showError(err.message || 'Google sign-in failed');
    } finally {
      setSocialLoading(null);
    }
  };

  const handleGithubLogin = async () => {
    setSocialLoading('github');
    try {
      await githubLogin();
      showSuccess('Signed in with GitHub!');
      navigate('/dashboard');
    } catch (err) {
      showError(err.message || 'GitHub sign-in failed');
    } finally {
      setSocialLoading(null);
    }
  };

  return (
    <div className="container" style={{ padding: '60px 0', display: 'flex', justifyContent: 'center', minHeight: '75vh', alignItems: 'center' }}>
      <div style={{ width: '100%', maxWidth: '420px' }}>
        <div style={{ backgroundColor: 'var(--bg-secondary)', padding: '40px', borderRadius: '8px', border: '1px solid var(--border-color)' }}>
          <h1 style={{ marginBottom: '24px', textAlign: 'center', fontSize: '26px' }}>Login to StarTech</h1>

          {/* Social Sign-in Buttons */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', marginBottom: '24px' }}>
            <button
              type="button"
              onClick={handleGoogleLogin}
              disabled={socialLoading !== null || loading}
              className="btn btn-outline"
              style={{
                width: '100%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '10px',
                padding: '10px',
                fontSize: '14px',
                backgroundColor: 'var(--bg)',
              }}
            >
              <FcGoogle size={18} />
              {socialLoading === 'google' ? 'Connecting Google...' : 'Continue with Google'}
            </button>

            <button
              type="button"
              onClick={handleGithubLogin}
              disabled={socialLoading !== null || loading}
              className="btn btn-outline"
              style={{
                width: '100%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '10px',
                padding: '10px',
                fontSize: '14px',
                backgroundColor: 'var(--bg)',
              }}
            >
              <FiGithub size={18} />
              {socialLoading === 'github' ? 'Connecting GitHub...' : 'Continue with GitHub'}
            </button>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', margin: '20px 0', color: 'var(--text-secondary)' }}>
            <hr style={{ flex: 1, borderColor: 'var(--border-color)' }} />
            <span style={{ padding: '0 10px', fontSize: '12px', textTransform: 'uppercase' }}>OR</span>
            <hr style={{ flex: 1, borderColor: 'var(--border-color)' }} />
          </div>

          {/* Email/Password Form */}
          <form onSubmit={handleSubmit}>
            <Input
              label="Email Address"
              type="email"
              name="email"
              placeholder="name@example.com"
              value={formData.email}
              onChange={handleInputChange}
              required
            />

            <Input
              label="Password"
              type="password"
              name="password"
              placeholder="••••••••"
              value={formData.password}
              onChange={handleInputChange}
              required
            />

            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
              <label style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '13px', cursor: 'pointer' }}>
                <input
                  type="checkbox"
                  name="rememberMe"
                  checked={formData.rememberMe}
                  onChange={handleInputChange}
                />
                Remember me
              </label>

              <Link to="/forgot-password" style={{ color: 'var(--accent-red)', fontSize: '13px', textDecoration: 'none' }}>
                Forgot Password?
              </Link>
            </div>

            <ButtonLoader
              type="submit"
              loading={loading}
              className="btn btn-primary"
              style={{ width: '100%', padding: '12px', fontSize: '16px' }}
            >
              Sign In
            </ButtonLoader>
          </form>

          <div style={{ marginTop: '24px', textAlign: 'center', fontSize: '14px' }}>
            <span style={{ color: 'var(--text-secondary)' }}>Don't have an account? </span>
            <Link to="/register" style={{ color: 'var(--accent-red)', fontWeight: 600, textDecoration: 'none' }}>
              Create Account
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
