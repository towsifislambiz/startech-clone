import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { FcGoogle } from 'react-icons/fc';
import { FiGithub } from 'react-icons/fi';
import { useAuth } from '../context/AuthContext';
import { useNotification } from '../context/NotificationContext';
import ButtonLoader from '../components/Common/ButtonLoader';
import Input from '../components/Common/Input';
import { useDocumentTitle } from '../hooks/useDocumentTitle';

const Register = () => {
  const navigate = useNavigate();
  const { signup, googleLogin, githubLogin } = useAuth();
  const { success: showSuccess, error: showError, info: showInfo } = useNotification();
  useDocumentTitle('Create Account');

  const [formData, setFormData] = useState({
    first_name: '',
    last_name: '',
    email: '',
    password: '',
    password_confirm: '',
    phone: '',
    agree: false,
  });
  const [loading, setLoading] = useState(false);
  const [socialLoading, setSocialLoading] = useState(null);

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!formData.first_name || !formData.email || !formData.password) {
      showError('Please fill in all required fields');
      return;
    }

    if (formData.password.length < 6) {
      showError('Password must be at least 6 characters long');
      return;
    }

    if (formData.password !== formData.password_confirm) {
      showError('Passwords do not match');
      return;
    }

    if (!formData.agree) {
      showError('Please accept the Terms & Conditions');
      return;
    }

    setLoading(true);
    try {
      const displayName = `${formData.first_name} ${formData.last_name}`.trim();
      await signup(formData.email, formData.password, displayName);
      showSuccess('Account created successfully!');
      showInfo('A verification email has been sent to your address.');
      navigate('/dashboard');
    } catch (err) {
      showError(err.message || 'Registration failed');
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleSignup = async () => {
    setSocialLoading('google');
    try {
      await googleLogin();
      showSuccess('Signed in with Google!');
      navigate('/dashboard');
    } catch (err) {
      showError(err.message || 'Google sign-in failed');
    } finally {
      setSocialLoading(null);
    }
  };

  const handleGithubSignup = async () => {
    setSocialLoading('github');
    try {
      await githubLogin();
      showSuccess('Signed in with GitHub!');
      navigate('/dashboard');
    } catch (err) {
      showError(err.message || 'GitHub sign-in failed');
    } finally {
      setSocialLoading(null);
    }
  };

  return (
    <div className="container" style={{ padding: '60px 0', display: 'flex', justifyContent: 'center', minHeight: '75vh', alignItems: 'center' }}>
      <div style={{ width: '100%', maxWidth: '440px' }}>
        <div style={{ backgroundColor: 'var(--bg-secondary)', padding: '40px', borderRadius: '8px', border: '1px solid var(--border-color)' }}>
          <h1 style={{ marginBottom: '24px', textAlign: 'center', fontSize: '26px' }}>Create Account</h1>

          {/* Social Buttons */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', marginBottom: '20px' }}>
            <button
              type="button"
              onClick={handleGoogleSignup}
              disabled={socialLoading !== null || loading}
              className="btn btn-outline"
              style={{
                width: '100%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '10px',
                padding: '10px',
                fontSize: '14px',
                backgroundColor: 'var(--bg)',
              }}
            >
              <FcGoogle size={18} />
              {socialLoading === 'google' ? 'Connecting Google...' : 'Sign up with Google'}
            </button>

            <button
              type="button"
              onClick={handleGithubSignup}
              disabled={socialLoading !== null || loading}
              className="btn btn-outline"
              style={{
                width: '100%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '10px',
                padding: '10px',
                fontSize: '14px',
                backgroundColor: 'var(--bg)',
              }}
            >
              <FiGithub size={18} />
              {socialLoading === 'github' ? 'Connecting GitHub...' : 'Sign up with GitHub'}
            </button>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', margin: '20px 0', color: 'var(--text-secondary)' }}>
            <hr style={{ flex: 1, borderColor: 'var(--border-color)' }} />
            <span style={{ padding: '0 10px', fontSize: '12px', textTransform: 'uppercase' }}>OR</span>
            <hr style={{ flex: 1, borderColor: 'var(--border-color)' }} />
          </div>

          <form onSubmit={handleSubmit}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
              <Input
                label="First Name"
                type="text"
                name="first_name"
                placeholder="Tanvir"
                value={formData.first_name}
                onChange={handleInputChange}
                required
              />
              <Input
                label="Last Name"
                type="text"
                name="last_name"
                placeholder="Hossain"
                value={formData.last_name}
                onChange={handleInputChange}
              />
            </div>

            <Input
              label="Email Address"
              type="email"
              name="email"
              placeholder="name@example.com"
              value={formData.email}
              onChange={handleInputChange}
              required
            />

            <Input
              label="Phone Number"
              type="tel"
              name="phone"
              placeholder="01700000000"
              value={formData.phone}
              onChange={handleInputChange}
            />

            <Input
              label="Password (min 6 chars)"
              type="password"
              name="password"
              placeholder="••••••••"
              value={formData.password}
              onChange={handleInputChange}
              required
            />

            <Input
              label="Confirm Password"
              type="password"
              name="password_confirm"
              placeholder="••••••••"
              value={formData.password_confirm}
              onChange={handleInputChange}
              required
            />

            <label style={{ display: 'flex', alignItems: 'flex-start', gap: '8px', marginBottom: '20px', cursor: 'pointer', fontSize: '13px' }}>
              <input
                type="checkbox"
                name="agree"
                checked={formData.agree}
                onChange={handleInputChange}
                required
                style={{ marginTop: '2px' }}
              />
              <span>I agree to the Terms & Conditions and Privacy Policy</span>
            </label>

            <ButtonLoader
              type="submit"
              loading={loading}
              className="btn btn-primary"
              style={{ width: '100%', padding: '12px', fontSize: '16px' }}
            >
              Create Account
            </ButtonLoader>
          </form>

          <div style={{ marginTop: '24px', textAlign: 'center', fontSize: '14px' }}>
            <span style={{ color: 'var(--text-secondary)' }}>Already have an account? </span>
            <Link to="/login" style={{ color: 'var(--accent-red)', fontWeight: 600, textDecoration: 'none' }}>
              Sign In
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Register;
