import api from './api';
import { handleApiError } from '../utils/errorHandler';
import { createSuccessResponse } from '../utils/response';

export const userService = {
  getProfile: async () => {
    try {
      const response = await api.get('/users/profile');
      return createSuccessResponse(response.data);
    } catch (error) {
      return handleApiError(error);
    }
  },

  updateProfile: async (userData) => {
    try {
      const response = await api.put('/users/profile', userData);
      return createSuccessResponse(response.data, 'Profile updated successfully');
    } catch (error) {
      return handleApiError(error);
    }
  },

  getWishlist: async () => {
    try {
      const response = await api.get('/users/wishlist');
      return createSuccessResponse(response.data);
    } catch (error) {
      return handleApiError(error);
    }
  },
};

export default userService;
