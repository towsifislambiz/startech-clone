import api from './api';
import { handleApiError } from '../utils/errorHandler';
import { createSuccessResponse } from '../utils/response';

export const paymentService = {
  initiateSSLCommerz: async (paymentDetails) => {
    try {
      const response = await api.post('/payment/sslcommerz/initiate', paymentDetails);
      return createSuccessResponse(response.data);
    } catch (error) {
      return handleApiError(error);
    }
  },

  initiateBKash: async (paymentDetails) => {
    try {
      const response = await api.post('/payment/bkash/initiate', paymentDetails);
      return createSuccessResponse(response.data);
    } catch (error) {
      return handleApiError(error);
    }
  },

  verifyPayment: async (transactionId) => {
    try {
      const response = await api.post(`/payment/verify/${transactionId}`);
      return createSuccessResponse(response.data);
    } catch (error) {
      return handleApiError(error);
    }
  },
};

export default paymentService;
