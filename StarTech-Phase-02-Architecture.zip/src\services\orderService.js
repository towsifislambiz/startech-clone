import api from './api';
import { handleApiError } from '../utils/errorHandler';
import { createSuccessResponse } from '../utils/response';

export const orderService = {
  createOrder: async (orderData) => {
    try {
      const response = await api.post('/orders', orderData);
      return createSuccessResponse(response.data, 'Order placed successfully');
    } catch (error) {
      return handleApiError(error);
    }
  },

  getUserOrders: async () => {
    try {
      const response = await api.get('/orders/my-orders');
      return createSuccessResponse(response.data);
    } catch (error) {
      return handleApiError(error);
    }
  },

  getOrderById: async (orderId) => {
    try {
      const response = await api.get(`/orders/${orderId}`);
      return createSuccessResponse(response.data);
    } catch (error) {
      return handleApiError(error);
    }
  },

  trackOrder: async (orderId) => {
    try {
      const response = await api.get(`/orders/track/${orderId}`);
      return createSuccessResponse(response.data);
    } catch (error) {
      return handleApiError(error);
    }
  },
};

export default orderService;
