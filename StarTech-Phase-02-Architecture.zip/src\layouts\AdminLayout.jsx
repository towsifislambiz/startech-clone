import React from 'react';
import { Link, Outlet, useLocation } from 'react-router-dom';
import { FiGrid, FiUsers, FiBox, FiShoppingBag, FiSettings, FiLogOut, FiShield } from 'react-icons/fi';
import Toast from '../components/Common/Toast';

const AdminLayout = () => {
  const location = useLocation();

  const navItems = [
    { label: 'Overview', icon: FiGrid, path: '/admin/dashboard' },
    { label: 'Products', icon: FiBox, path: '/admin/products' },
    { label: 'Orders', icon: FiShoppingBag, path: '/admin/orders' },
    { label: 'Users', icon: FiUsers, path: '/admin/users' },
    { label: 'Settings', icon: FiSettings, path: '/admin/settings' },
  ];

  return (
    <div style={{ display: 'flex', minHeight: '100vh', backgroundColor: 'var(--bg)' }}>
      {/* Admin Sidebar */}
      <aside style={{ width: '260px', backgroundColor: 'var(--bg-secondary)', borderRight: '1px solid var(--border-color)', padding: '20px', display: 'flex', flexDirection: 'column' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '30px', paddingBottom: '16px', borderBottom: '1px solid var(--border-color)' }}>
          <FiShield size={24} style={{ color: 'var(--accent-red)' }} />
          <div>
            <h4 style={{ margin: 0 }}>StarTech Admin</h4>
            <small style={{ color: 'var(--text-secondary)' }}>Control Panel</small>
          </div>
        </div>

        <nav style={{ display: 'flex', flexDirection: 'column', gap: '8px', flex: 1 }}>
          {navItems.map((item, idx) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={idx}
                to={item.path}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '12px',
                  padding: '12px 16px',
                  borderRadius: '6px',
                  color: isActive ? 'var(--white)' : 'var(--text-primary)',
                  backgroundColor: isActive ? 'var(--accent-red)' : 'transparent',
                  textDecoration: 'none',
                  fontWeight: 500,
                  fontSize: '14px',
                }}
              >
                <Icon /> {item.label}
              </Link>
            );
          })}
        </nav>

        <Link
          to="/"
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '12px',
            padding: '12px 16px',
            borderRadius: '6px',
            color: 'var(--text-secondary)',
            textDecoration: 'none',
            fontSize: '14px',
            marginTop: 'auto',
          }}
        >
          <FiLogOut /> Back to Store
        </Link>
      </aside>

      {/* Main Admin Area */}
      <main style={{ flex: 1, padding: '30px' }}>
        <Outlet />
      </main>

      <Toast />
    </div>
  );
};

export default AdminLayout;
