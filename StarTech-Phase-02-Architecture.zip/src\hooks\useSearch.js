import { useState } from 'react';
import useDebounce from './useDebounce';

export const useSearch = (initialQuery = '') => {
  const [query, setQuery] = useState(initialQuery);
  const debouncedQuery = useDebounce(query, 300);

  const clearSearch = () => setQuery('');

  return {
    query,
    debouncedQuery,
    setQuery,
    clearSearch,
  };
};

export default useSearch;
