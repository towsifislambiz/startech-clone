import { useState, useMemo } from 'react';

export const useFilter = (initialItems = []) => {
  const [selectedBrands, setSelectedBrands] = useState([]);
  const [selectedPrices, setSelectedPrices] = useState([]);
  const [inStockOnly, setInStockOnly] = useState(false);
  const [minRating, setMinRating] = useState(0);
  const [sort, setSort] = useState('popular');

  const toggleBrand = (b) =>
    setSelectedBrands((prev) => (prev.includes(b) ? prev.filter((x) => x !== b) : [...prev, b]));

  const togglePrice = (label) =>
    setSelectedPrices((prev) => (prev.includes(label) ? prev.filter((x) => x !== label) : [...prev, label]));

  const clearAll = () => {
    setSelectedBrands([]);
    setSelectedPrices([]);
    setInStockOnly(false);
    setMinRating(0);
  };

  const filteredItems = useMemo(() => {
    let list = [...initialItems];
    if (selectedBrands.length) list = list.filter((p) => selectedBrands.includes(p.brand));
    if (inStockOnly) list = list.filter((p) => p.stock);
    if (minRating) list = list.filter((p) => (p.rating || 0) >= minRating);
    switch (sort) {
      case 'price_low':
        list.sort((a, b) => a.price - b.price);
        break;
      case 'price_high':
        list.sort((a, b) => b.price - a.price);
        break;
      case 'rating':
        list.sort((a, b) => (b.rating || 0) - (a.rating || 0));
        break;
      default:
        list.sort((a, b) => (b.reviews || 0) - (a.reviews || 0));
    }
    return list;
  }, [initialItems, selectedBrands, selectedPrices, inStockOnly, minRating, sort]);

  return {
    selectedBrands,
    selectedPrices,
    inStockOnly,
    minRating,
    sort,
    filteredItems,
    toggleBrand,
    togglePrice,
    setInStockOnly,
    setMinRating,
    setSort,
    clearAll,
  };
};

export default useFilter;
