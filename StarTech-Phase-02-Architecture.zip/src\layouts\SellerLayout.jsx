import React from 'react';
import { Link, Outlet, useLocation } from 'react-router-dom';
import { FiGrid, FiBox, FiShoppingBag, FiDollarSign, FiLogOut, FiHome } from 'react-icons/fi';
import Toast from '../components/Common/Toast';

const SellerLayout = () => {
  const location = useLocation();

  const navItems = [
    { label: 'Store Overview', icon: FiGrid, path: '/seller/dashboard' },
    { label: 'My Products', icon: FiBox, path: '/seller/products' },
    { label: 'Customer Orders', icon: FiShoppingBag, path: '/seller/orders' },
    { label: 'Earnings', icon: FiDollarSign, path: '/seller/earnings' },
  ];

  return (
    <div style={{ display: 'flex', minHeight: '100vh', backgroundColor: 'var(--bg)' }}>
      {/* Seller Sidebar */}
      <aside style={{ width: '260px', backgroundColor: 'var(--bg-secondary)', borderRight: '1px solid var(--border-color)', padding: '20px', display: 'flex', flexDirection: 'column' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '30px', paddingBottom: '16px', borderBottom: '1px solid var(--border-color)' }}>
          <FiHome size={24} style={{ color: 'var(--accent-red)' }} />
          <div>
            <h4 style={{ margin: 0 }}>Seller Center</h4>
            <small style={{ color: 'var(--text-secondary)' }}>Merchant Portal</small>
          </div>
        </div>

        <nav style={{ display: 'flex', flexDirection: 'column', gap: '8px', flex: 1 }}>
          {navItems.map((item, idx) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={idx}
                to={item.path}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '12px',
                  padding: '12px 16px',
                  borderRadius: '6px',
                  color: isActive ? 'var(--white)' : 'var(--text-primary)',
                  backgroundColor: isActive ? 'var(--accent-red)' : 'transparent',
                  textDecoration: 'none',
                  fontWeight: 500,
                  fontSize: '14px',
                }}
              >
                <Icon /> {item.label}
              </Link>
            );
          })}
        </nav>

        <Link
          to="/"
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '12px',
            padding: '12px 16px',
            borderRadius: '6px',
            color: 'var(--text-secondary)',
            textDecoration: 'none',
            fontSize: '14px',
            marginTop: 'auto',
          }}
        >
          <FiLogOut /> Back to Store
        </Link>
      </aside>

      {/* Main Seller Area */}
      <main style={{ flex: 1, padding: '30px' }}>
        <Outlet />
      </main>

      <Toast />
    </div>
  );
};

export default SellerLayout;
