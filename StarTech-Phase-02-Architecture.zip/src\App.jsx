import React from 'react';
import { BrowserRouter as Router } from 'react-router-dom';
import { Provider } from 'react-redux';

// Providers
import { ThemeProvider } from './context/ThemeContext';
import { CartProvider } from './context/CartContext';
import { AuthProvider } from './context/AuthContext';
import { NotificationProvider } from './context/NotificationContext';
import { store } from './redux/store';

// Components
import ErrorBoundary from './components/Common/ErrorBoundary';
import AppRoutes from './routes';
import useScrollTop from './hooks/useScrollTop';

const ScrollToTop = () => {
  useScrollTop();
  return null;
};

function App() {
  return (
    <ErrorBoundary>
      <Provider store={store}>
        <ThemeProvider>
          <AuthProvider>
            <CartProvider>
              <NotificationProvider>
                <Router>
                  <ScrollToTop />
                  <AppRoutes />
                </Router>
              </NotificationProvider>
            </CartProvider>
          </AuthProvider>
        </ThemeProvider>
      </Provider>
    </ErrorBoundary>
  );
}

export default App;
