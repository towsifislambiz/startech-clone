import api from './api';
import { handleApiError } from '../utils/errorHandler';
import { createSuccessResponse } from '../utils/response';

export const sellerService = {
  getSellerStats: async () => {
    try {
      const response = await api.get('/seller/stats');
      return createSuccessResponse(response.data);
    } catch (error) {
      return handleApiError(error);
    }
  },

  getSellerProducts: async (params) => {
    try {
      const response = await api.get('/seller/products', { params });
      return createSuccessResponse(response.data);
    } catch (error) {
      return handleApiError(error);
    }
  },

  createProduct: async (productData) => {
    try {
      const response = await api.post('/seller/products', productData);
      return createSuccessResponse(response.data, 'Product created successfully');
    } catch (error) {
      return handleApiError(error);
    }
  },
};

export default sellerService;
