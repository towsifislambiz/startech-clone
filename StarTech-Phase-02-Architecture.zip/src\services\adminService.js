import api from './api';
import { handleApiError } from '../utils/errorHandler';
import { createSuccessResponse } from '../utils/response';

export const adminService = {
  getDashboardStats: async () => {
    try {
      const response = await api.get('/admin/stats');
      return createSuccessResponse(response.data);
    } catch (error) {
      return handleApiError(error);
    }
  },

  getUsersList: async (params) => {
    try {
      const response = await api.get('/admin/users', { params });
      return createSuccessResponse(response.data);
    } catch (error) {
      return handleApiError(error);
    }
  },

  getAllOrders: async (params) => {
    try {
      const response = await api.get('/admin/orders', { params });
      return createSuccessResponse(response.data);
    } catch (error) {
      return handleApiError(error);
    }
  },
};

export default adminService;
